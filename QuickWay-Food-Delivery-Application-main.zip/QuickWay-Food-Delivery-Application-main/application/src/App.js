import './App.css';
import React from 'react';
import Home from './screens/Home';

function App() {
  return (
    <>
      <div>
        <Home/>
      </div>
    </>
  );
}

export default App;
