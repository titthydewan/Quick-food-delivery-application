# QuickWay-Food-Delivery-Application
QuickWay is an online food ordering and delivery platform. QuickWay provides on-demand deliveries on the same day of ordering. QuickWay also provides information, menus and user-reviews of restaurants and food shops.

